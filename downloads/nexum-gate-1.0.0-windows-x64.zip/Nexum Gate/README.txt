Nexum Gate 1.0.0 — Windows x64

VST3: copy the entire Nexum Gate.vst3 folder into
C:/Program Files/Common Files/VST3/NEXUM/
Then scan for plugins in your DAW.
Nexum Gate is an audio effect.
Standalone: launch Nexum Gate.exe from this extracted folder.

Full corresponding source: nexum-suite-source-2026-11-03.zip
Website: https://nexum-audio.com
