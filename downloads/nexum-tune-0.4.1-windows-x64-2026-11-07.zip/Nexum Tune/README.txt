Nexum Tune 0.4.1 — Windows x64
Packaged 2026-11-07. Development build, not a promise of production readiness.

Copy the complete Nexum Tune.vst3 folder to your VST3 folder, then rescan your DAW.
Typical system location: C:/Program Files/Common Files/VST3/NEXUM/
Standalone: open Nexum Tune.exe. Audio effects require a configured input.
Full corresponding source: nexum-suite-source-2026-11-07.zip
Repository: https://github.com/nexum-audio/nexum-tune
All projects use AGPL-3.0-only for original implementation; dependencies retain licenses.
